import React from 'react'

const P_info = () => {
  return (
    <div>
      
      
    </div>
  )
}

export default P_info
